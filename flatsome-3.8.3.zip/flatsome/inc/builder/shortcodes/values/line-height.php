<?php
	return array(
		'xs'   => array( 'title' => 'XS'),
	    's'   => array( 'title' => 'S'),
	    'm' => array( 'title' => 'M'),
	    'l'  => array( 'title' => 'L'),
	);
?>